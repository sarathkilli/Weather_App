import './Weather.css'
import searchicon from '../Images/search.png'
import clearicon from '../Images/clear.png'
import cloudicon from '../Images/cloud.png'
import drizzleicon from '../Images/drizzle.png'
import humidicon from '../Images/humidity.png'
import rainicon from '../Images/rain.png'
import snowicon from '../Images/snow.png'
import windicon from '../Images/wind.png'
import axios from 'axios';
import { useEffect, useRef, useState } from 'react'
function Weather(){
    const [weatherdata,setWeatherdata]=useState(null);
    const [cityname,setCityname]=useState("");
    const inref=useRef();
    const allicons={
        "01d":clearicon,
        "01n":clearicon,
        "02d":cloudicon,
        "02n":cloudicon,
        "03d":cloudicon,
        "03n":cloudicon,
        "04d":drizzleicon,
        "04n":drizzleicon,
        "09d":rainicon,
        "09n":rainicon,
        "10d":rainicon,
        "10n":rainicon,
        "13d":snowicon,
        "13n":snowicon
    }
    const search=async (city)=>{
        if(city === ""){
            alert("Enter the Cityname!");
            return;
        }
        try{
            const API_KEY = process.env.REACT_APP_WEATHER_API_KEY;
            const res=await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`);
            console.log(res);
            if (res.status !== 200) {
                alert("Failed to fetch weather data");
                return;
            }
            const icon=allicons[res.weather[0].icon]||clearicon;
            setWeatherdata({
                humidity:res.data.main.humidity,
                windspeed:res.data.wind.speed,
                temparature:Math.floor(res.data.main.temp),
                location:res.data.name,
                icon:icon
            })
        }
        catch(error){
            setWeatherdata(null);
            //console.error(error);
        }
    }
    const handleclick=()=>{
        const city=inref.current.value;
        setCityname(city);
        search(city);
    }
        useEffect(()=>{
            search(cityname)
        },[])
    return (
        <>
        <div className="weather">
            <div className="search-bar">
                <input ref={inref} type="text" placeholder="Enter City"></input>
                <img src={searchicon} alt="" onClick={handleclick}/>
            </div>
            {weatherdata?<>
                    <img src={weatherdata.icon} alt='' className='weathor-icon'/>
                <p className='temparature'>{weatherdata.temparature}°c</p>
                <p className='Cityname'>{weatherdata.location}</p>
                <div className='weather-data'>
                    <div className='col'>
                        <img src={humidicon} alt=''/>
                        <div>
                        <p>{weatherdata.humidity}%</p>
                        <span>Humidity</span>
                        </div>
                    </div>
                    <div className='col'>
                        <img src={windicon} alt=''/>
                        <div>
                        <p>{weatherdata.windspeed} Km/hr</p>
                        <span>Wind Speed</span>
                        </div>
                    </div>
                </div>
            </>:<p>Loading...</p>}
            
        </div>
        </>
    )
}
export default Weather