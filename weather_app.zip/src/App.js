import './App.css';
import Weather from './Components/Weather'
function App() {
  return (
    <div className="App">
      <Weather/>
    </div>
  );
}

export default App;
